@echo off
./xlarig --donate-level 1 -o de.qrl.herominers.com:1166 -u Q010300df41aca7934c197827a40582450cd0c7f56223666baef4fd4f3020652c501894d2b46efa -p XX -a rx/0 -k 
pause