@echo off
./xlarig --donate-level 1 -o de.scala.herominers.com:1190 -u Ssy2Szo44wNeojzrrZh2n77b4ZsZ1WbFH46kBsJur2F5iZyrYNLi1Tb4FMj4fGmgRjUrLzZp89KASNqSjfAm3gK589ZERaUAHT -p XX -a panthera -k 
pause