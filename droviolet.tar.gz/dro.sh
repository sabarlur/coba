@echo off
./violetminer --donate-level 1 -o de.dero.herominers.com:1117 -u dERirD3WyQi4udWH7478H66Ryqn3syEU8bywCQEu3k5ULohQRcz4uoXP12NjmN4STmEDbpHZWqa7bPRiHNFPFgTBPmcBZL39Yt226qJzNXd5a -p DRX -a astrobwt -k 
pause